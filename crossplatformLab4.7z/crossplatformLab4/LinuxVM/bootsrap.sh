﻿echo "ASPNETCORE_ENVIRONMENT=Development" >> /etc/environment
